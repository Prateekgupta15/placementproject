from django.contrib import admin
from .models import PdfForms
# Register your models here.
admin.site.register(PdfForms)